#include <string>
#include <iostream>
#include <iomanip>
#include "Books.h"
#include "cashRegister.h"
#include "inventory.h"
#include "reportModule.h"
using namespace std;


int main() {
	main2();
	report().mainMenu();
	cout << "End of Program" << endl;
	cout << "---------------" << endl;
	system("break");
	return 0;
}



